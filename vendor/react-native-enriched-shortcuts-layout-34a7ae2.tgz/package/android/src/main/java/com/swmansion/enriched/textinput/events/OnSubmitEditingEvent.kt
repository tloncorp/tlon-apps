package com.swmansion.enriched.textinput.events

import android.text.Editable
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.WritableMap
import com.facebook.react.uimanager.events.Event

class OnSubmitEditingEvent(
  surfaceId: Int,
  viewId: Int,
  private val editable: Editable?,
  private val experimentalSynchronousEvents: Boolean,
) : Event<OnSubmitEditingEvent>(surfaceId, viewId) {
  override fun getEventName(): String = EVENT_NAME

  override fun getEventData(): WritableMap {
    val eventData: WritableMap = Arguments.createMap()
    val text = editable.toString()
    val normalizedText = text.replace(Regex("\\u200B"), "")
    eventData.putString("text", normalizedText)
    return eventData
  }

  override fun experimental_isSynchronous(): Boolean = experimentalSynchronousEvents

  companion object {
    const val EVENT_NAME: String = "onSubmitEditing"
  }
}
