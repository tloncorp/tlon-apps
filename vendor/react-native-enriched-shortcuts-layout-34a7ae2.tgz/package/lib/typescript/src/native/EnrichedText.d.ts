import type { EnrichedTextProps } from '../types';
export declare const EnrichedText: ({ ref, children, style, htmlStyle: _htmlStyle, useHtmlNormalizer, ellipsizeMode, numberOfLines, selectable, selectionColor, onLinkPress: _onLinkPress, onMentionPress: _onMentionPress, ...rest }: EnrichedTextProps) => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=EnrichedText.d.ts.map