import type { Editor } from '@tiptap/react';
import type { MentionPluginOptions } from './types';
export declare function subscribeMentionEvents(editor: Editor, callbacksRef: MentionPluginOptions['callbacksRef']): () => void;
//# sourceMappingURL=subscribeMentionEvents.d.ts.map