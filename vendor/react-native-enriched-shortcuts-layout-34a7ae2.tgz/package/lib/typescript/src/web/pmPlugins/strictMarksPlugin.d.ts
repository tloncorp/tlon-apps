import { Extension } from '@tiptap/core';
export declare const StrictMarksPlugin: Extension<any, any>;
//# sourceMappingURL=strictMarksPlugin.d.ts.map