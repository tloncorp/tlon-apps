import type { StateField } from '@tiptap/pm/state';
import type { MentionPluginOptions, TriggerState } from './types';
export declare function makeMentionPluginState(options: MentionPluginOptions): StateField<TriggerState>;
//# sourceMappingURL=makeMentionPluginState.d.ts.map