import { Extension } from '@tiptap/core';
import type { MentionPluginOptions } from './types';
export type { MentionPluginOptions, TriggerState } from './types';
export { mentionPluginKey } from './mentionPluginKey';
export { setMention } from './setMention';
export { startMention } from './startMention';
export { subscribeMentionEvents } from './subscribeMentionEvents';
export declare function createMentionPlugin(options: MentionPluginOptions): Extension;
//# sourceMappingURL=index.d.ts.map