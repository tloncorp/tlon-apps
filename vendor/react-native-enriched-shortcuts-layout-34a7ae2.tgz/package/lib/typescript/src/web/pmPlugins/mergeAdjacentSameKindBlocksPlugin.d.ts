import { Extension } from '@tiptap/core';
export declare const MergeAdjacentSameKindBlocksPlugin: Extension<any, any>;
//# sourceMappingURL=mergeAdjacentSameKindBlocksPlugin.d.ts.map