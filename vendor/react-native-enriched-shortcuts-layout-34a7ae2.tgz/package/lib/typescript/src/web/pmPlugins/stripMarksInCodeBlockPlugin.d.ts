import { Extension } from '@tiptap/core';
export declare const StripMarksInCodeBlockPlugin: Extension<any, any>;
//# sourceMappingURL=stripMarksInCodeBlockPlugin.d.ts.map