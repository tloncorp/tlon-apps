import { Extension } from '@tiptap/core';
export declare const StripMarksOnImagePlugin: Extension<any, any>;
//# sourceMappingURL=stripMarksOnImagePlugin.d.ts.map