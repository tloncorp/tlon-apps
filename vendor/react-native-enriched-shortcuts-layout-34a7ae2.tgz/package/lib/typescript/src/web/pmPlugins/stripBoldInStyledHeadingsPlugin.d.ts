import { Extension } from '@tiptap/core';
import type { HtmlStyle } from '../../types';
declare module '@tiptap/core' {
    interface Commands<ReturnType> {
        stripBoldInStyledHeadings: {
            normalizeBoldInStyledHeadings: () => ReturnType;
        };
    }
}
export declare function createStripBoldInStyledHeadingsPlugin(getStyle: () => Required<HtmlStyle>): Extension<any, any>;
//# sourceMappingURL=stripBoldInStyledHeadingsPlugin.d.ts.map