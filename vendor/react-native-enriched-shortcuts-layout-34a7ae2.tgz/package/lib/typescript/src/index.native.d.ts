export { EnrichedTextInput } from './native/EnrichedTextInput';
export type { EnrichedInputStyle, EnrichedTextInputProps, OnChangeTextEvent, OnChangeHtmlEvent, OnChangeStateEvent, OnLinkDetected, OnMentionDetected, OnChangeSelectionEvent, OnKeyPressEvent, OnPasteImagesEvent, OnSubmitEditing, HtmlStyle, MentionStyleProperties, FocusEvent, BlurEvent, EnrichedTextInputInstance, ContextMenuItem, OnChangeMentionEvent, TextShortcut, TextShortcutStyle, } from './types';
export { EnrichedText } from './native/EnrichedText';
export type { EnrichedTextProps, EnrichedTextInstance, EnrichedTextHtmlStyle, OnMentionPressEvent, OnLinkPressEvent, } from './types';
//# sourceMappingURL=index.native.d.ts.map